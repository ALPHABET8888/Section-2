# Section 2 - Challenge #2

A Pen created on CodePen.io. Original URL: [https://codepen.io/xnjentxh-the-selector/pen/gOEPoYM](https://codepen.io/xnjentxh-the-selector/pen/gOEPoYM).

